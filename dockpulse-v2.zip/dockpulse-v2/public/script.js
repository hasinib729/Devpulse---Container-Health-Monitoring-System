document.addEventListener('DOMContentLoaded', () => {
    // === Authentication Simulation ===
    const loginForm = document.getElementById('login-form');
    const loginScreen = document.getElementById('login-screen');
    const dashboard = document.getElementById('dashboard');
    const logoutBtn = document.getElementById('logout-btn');
    const loginError = document.getElementById('login-error');

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const user = document.getElementById('username').value;
        const pass = document.getElementById('password').value;
        
        if (user === 'admin' && pass === 'admin') {
            loginScreen.classList.add('d-none');
            dashboard.classList.remove('d-none');
            initializeDashboard();
        } else {
            loginError.classList.remove('d-none');
        }
    });

    logoutBtn.addEventListener('click', () => {
        dashboard.classList.add('d-none');
        loginScreen.classList.remove('d-none');
        if(socket) socket.disconnect();
    });

    // === Global State ===
    let socket;
    let metricsChart;
    let selectedContainerId = null;
    let gravityEnabled = true;

    // === DOM Elements ===
    const grid = document.getElementById('containers-grid');
    const totalContainersEl = document.getElementById('total-containers');
    const logsContainer = document.getElementById('logs-container');
    const toastContainer = document.getElementById('toast-container');
    const gravityToggle = document.getElementById('gravity-toggle');
    const gravityText = document.getElementById('gravity-text');
    const selectedTitle = document.getElementById('selected-container-name');

    // === Initialize Dashboard ===
    function initializeDashboard() {
        socket = io();
        initChart();

        socket.on('connect', () => {
            showToast('System', 'Connected to DockPulse Server', 'info');
        });

        socket.on('containers_list', (containers) => {
            renderContainers(containers);
        });

        socket.on('container_stats', (stats) => {
            updateContainerCardStats(stats);
            if (stats.id === selectedContainerId) {
                updateChart(stats);
            }
        });

        socket.on('container_log', (logData) => {
            if (logData.id === selectedContainerId) {
                appendLog(logData.log, logData.timestamp);
            }
        });

        socket.on('alert', (alert) => {
            showToast('System Alert', alert.message, alert.type);
        });
        
        // Request stats every 2 seconds for all visible containers
        setInterval(() => {
            document.querySelectorAll('.container-card').forEach(card => {
                const id = card.dataset.id;
                socket.emit('request_stats', id);
            });
        }, 2000);
    }

    // === Chart.js Setup ===
    function initChart() {
        const ctx = document.getElementById('metricsChart').getContext('2d');
        
        Chart.defaults.color = '#94a3b8';
        Chart.defaults.font.family = "'Outfit', sans-serif";

        metricsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array(10).fill(''),
                datasets: [
                    {
                        label: 'CPU (%)',
                        data: Array(10).fill(0),
                        borderColor: '#0ea5e9',
                        backgroundColor: 'rgba(14, 165, 233, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Memory (%)',
                        data: Array(10).fill(0),
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 0 },
                scales: {
                    y: { beginAtZero: true, max: 100, grid: { color: 'rgba(255,255,255,0.05)' } },
                    x: { grid: { display: false } }
                },
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    }

    function updateChart(stats) {
        const data = metricsChart.data;
        // Shift labels (fake time)
        const now = new Date();
        data.labels.push(`${now.getSeconds()}s`);
        data.labels.shift();

        // Update CPU
        data.datasets[0].data.push(stats.cpu);
        data.datasets[0].data.shift();

        // Update Memory
        data.datasets[1].data.push(stats.memory);
        data.datasets[1].data.shift();

        metricsChart.update();
    }

    // === Render Containers ===
    function renderContainers(containers) {
        totalContainersEl.textContent = `${containers.length} Total`;
        
        // We do a smart update to prevent completely removing elements during gravity mode
        // If gravity is off, replacing innerHTML destroys the floating divs.
        // For simplicity in this demo, if gravity is OFF, we don't rerender the grid layout, just update the data attributes.
        
        if (!gravityEnabled) {
            // Just update inner text/classes of existing cards if possible
            return; 
        }

        grid.innerHTML = '';

        containers.forEach(c => {
            const isRunning = c.state === 'running';
            const statusClass = isRunning ? 'status-running' : (c.state === 'exited' ? 'status-exited' : 'status-paused');
            const badgeClass = isRunning ? 'bg-success' : 'bg-danger';
            
            const col = document.createElement('div');
            col.className = 'col-md-6 col-xl-6';
            
            col.innerHTML = `
                <div class="glass-card container-card p-3 ${statusClass} h-100" data-id="${c.id}" data-state="${c.state}">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h6 class="fw-bold mb-0 text-truncate" style="max-width: 180px;" title="${c.name}">${c.name}</h6>
                            <small class="text-muted text-truncate d-block" style="max-width: 180px;">${c.image}</small>
                        </div>
                        <span class="badge ${badgeClass}">${c.state}</span>
                    </div>
                    
                    <div class="mt-3 stats-area">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>CPU</span> <span class="cpu-text fw-bold">0%</span>
                        </div>
                        <div class="progress mb-2">
                            <div class="progress-bar bg-info cpu-bar" style="width: 0%"></div>
                        </div>
                        
                        <div class="d-flex justify-content-between small mb-1">
                            <span>Memory</span> <span class="mem-text fw-bold">0%</span>
                        </div>
                        <div class="progress mb-3">
                            <div class="progress-bar bg-success mem-bar" style="width: 0%"></div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-auto pt-2 border-top border-secondary">
                        <button class="btn btn-sm btn-outline-info view-logs-btn" data-id="${c.id}" data-name="${c.name}">
                            <i class="fa-solid fa-desktop me-1"></i> Monitor
                        </button>
                        ${!isRunning ? `<button class="btn btn-sm btn-outline-warning restart-btn" data-id="${c.id}">
                            <i class="fa-solid fa-rotate-right me-1"></i> Recover
                        </button>` : ''}
                    </div>
                </div>
            `;
            grid.appendChild(col);
        });

        // Attach events
        document.querySelectorAll('.view-logs-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = btn.dataset.id;
                const name = btn.dataset.name;
                selectContainer(id, name);
                e.stopPropagation();
            });
        });

        document.querySelectorAll('.restart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = btn.dataset.id;
                socket.emit('restart_container', id);
                e.stopPropagation();
            });
        });
    }

    function updateContainerCardStats(stats) {
        const card = document.querySelector(`.container-card[data-id="${stats.id}"]`);
        if (card) {
            card.querySelector('.cpu-text').textContent = `${stats.cpu}%`;
            card.querySelector('.cpu-bar').style.width = `${stats.cpu}%`;
            
            card.querySelector('.mem-text').textContent = `${stats.memory}% (${stats.memoryRaw})`;
            card.querySelector('.mem-bar').style.width = `${stats.memory}%`;
            
            // Auto Recovery simulation detection
            if (parseFloat(stats.cpu) > 90) {
                card.classList.add('border-danger');
                showToast('Warning', `Container ${stats.id.substring(0,8)} CPU > 90%!`, 'error');
            } else {
                card.classList.remove('border-danger');
            }
        }
    }

    // === Monitor Selection & Logs ===
    function selectContainer(id, name) {
        selectedContainerId = id;
        selectedTitle.textContent = `Monitoring: ${name}`;
        
        // Visual selection
        document.querySelectorAll('.container-card').forEach(c => c.classList.remove('selected'));
        const card = document.querySelector(`.container-card[data-id="${id}"]`);
        if (card) card.classList.add('selected');

        // Reset chart
        metricsChart.data.datasets.forEach(ds => ds.data = Array(10).fill(0));
        metricsChart.update();

        // Reset and subscribe to logs
        logsContainer.innerHTML = '';
        socket.emit('subscribe_logs', id);
    }

    function appendLog(text, time) {
        const timeObj = new Date(time);
        const timeStr = timeObj.toLocaleTimeString([], {hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit'});
        
        // Simple heuristic for log severity
        let textClass = 'text-light';
        const lowerText = text.toLowerCase();
        if (lowerText.includes('error') || lowerText.includes('exception') || lowerText.includes('fail')) textClass = 'log-error';
        else if (lowerText.includes('warn')) textClass = 'log-warn';
        else if (lowerText.includes('info')) textClass = 'log-info';

        const div = document.createElement('div');
        div.className = 'log-entry';
        div.innerHTML = `<span class="log-time">[${timeStr}]</span> <span class="${textClass}">${escapeHtml(text)}</span>`;
        
        logsContainer.appendChild(div);
        
        // Auto scroll
        logsContainer.scrollTop = logsContainer.scrollHeight;
    }

    document.getElementById('clear-logs').addEventListener('click', () => {
        logsContainer.innerHTML = '';
    });

    // === Toasts ===
    function showToast(title, message, type='info') {
        const id = 'toast-' + Date.now();
        let icon = 'fa-circle-info text-info';
        if(type==='error') icon = 'fa-triangle-exclamation text-danger';
        if(type==='success') icon = 'fa-circle-check text-success';

        const html = `
            <div id="${id}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <i class="fa-solid ${icon} me-2"></i>
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">${message}</div>
            </div>
        `;
        toastContainer.insertAdjacentHTML('beforeend', html);
        const toastEl = document.getElementById(id);
        const bsToast = new bootstrap.Toast(toastEl, { delay: 5000 });
        bsToast.show();
        toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
    }

    // === Antigravity Effects ===
    gravityToggle.addEventListener('click', () => {
        gravityEnabled = !gravityEnabled;
        
        if (!gravityEnabled) {
            gravityToggle.classList.replace('btn-outline-warning', 'btn-warning');
            gravityToggle.classList.add('text-dark');
            gravityText.textContent = "Enable Gravity";
            document.body.classList.add('zero-gravity');
            activateAntigravity();
        } else {
            gravityToggle.classList.replace('btn-warning', 'btn-outline-warning');
            gravityToggle.classList.remove('text-dark');
            gravityText.textContent = "Disable Gravity";
            document.body.classList.remove('zero-gravity');
            deactivateAntigravity();
        }
    });

    function activateAntigravity() {
        const cards = document.querySelectorAll('.container-card');
        const gridRect = grid.getBoundingClientRect();
        
        cards.forEach((card, index) => {
            // Get current absolute position to avoid sudden jumping
            const rect = card.getBoundingClientRect();
            
            // Set styles for floating
            card.style.width = `${rect.width}px`;
            card.style.height = `${rect.height}px`;
            card.style.position = 'fixed';
            card.style.top = `${rect.top}px`;
            card.style.left = `${rect.left}px`;
            
            card.classList.add('floating');
            
            // Randomize animation
            const delay = Math.random() * -20; // negative delay starts animation midway
            const duration = 15 + Math.random() * 15;
            card.style.animationDelay = `${delay}s`;
            card.style.animationDuration = `${duration}s`;
        });
        
        showToast('Zero Gravity', 'Antigravity mode activated. Container metrics are still updating.', 'info');
    }

    function deactivateAntigravity() {
        const cards = document.querySelectorAll('.container-card');
        cards.forEach(card => {
            card.classList.remove('floating');
            card.style.width = '';
            card.style.height = '';
            card.style.position = '';
            card.style.top = '';
            card.style.left = '';
            card.style.animationDelay = '';
            card.style.animationDuration = '';
        });
        
        // Force re-render to snap back to grid perfectly
        if (socket) socket.emit('request_list');
    }

    function escapeHtml(unsafe) {
        return unsafe
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
    }
});
