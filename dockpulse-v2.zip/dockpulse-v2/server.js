const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Docker = require('dockerode');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Windows users usually use Docker Desktop which exposes a different socket or uses named pipes
// But we'll fallback to default linux socket if we don't pass an explicit one.
// The Dockerode default usually handles standard connections automatically if DOCKER_HOST is not set.
let docker;
if (process.platform === 'win32') {
    // Docker Desktop for Windows often exposes //./pipe/docker_engine
    // Try standard pipe first, though standard dockerode config often just works if Docker Desktop is running
    docker = new Docker({ socketPath: '//./pipe/docker_engine' });
} else {
    docker = new Docker({ socketPath: '/var/run/docker.sock' });
}

// Serve static files from 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Store active container log streams to prevent memory leaks
const activeLogStreams = new Map();

// Parse docker stats payload
function calculateCpuPercent(stat) {
    if (!stat.cpu_stats || !stat.precpu_stats) return 0;
    
    const cpuDelta = stat.cpu_stats.cpu_usage.total_usage - stat.precpu_stats.cpu_usage.total_usage;
    const systemDelta = stat.cpu_stats.system_cpu_usage - stat.precpu_stats.system_cpu_usage;
    
    if (systemDelta > 0 && cpuDelta > 0) {
        const cpus = stat.cpu_stats.cpu_usage.percpu_usage ? stat.cpu_stats.cpu_usage.percpu_usage.length : (stat.cpu_stats.online_cpus || 1);
        return ((cpuDelta / systemDelta) * cpus * 100).toFixed(2);
    }
    return 0;
}

function calculateMemoryPercent(stat) {
    if (!stat.memory_stats || !stat.memory_stats.usage) return 0;
    const usage = stat.memory_stats.usage;
    const limit = stat.memory_stats.limit || 1;
    return ((usage / limit) * 100).toFixed(2);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Main socket connection
io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Initial load: send all containers
    sendContainersList(socket);

    // Set up polling for container list and stats
    const listInterval = setInterval(() => sendContainersList(socket), 5000);

    // Handle requests for real-time stats
    socket.on('request_stats', async (containerId) => {
        try {
            const container = docker.getContainer(containerId);
            const stats = await container.stats({ stream: false });
            
            const cpu = calculateCpuPercent(stats);
            const memory = calculateMemoryPercent(stats);
            
            let netRx = 0, netTx = 0;
            if (stats.networks) {
                Object.values(stats.networks).forEach(net => {
                    netRx += net.rx_bytes;
                    netTx += net.tx_bytes;
                });
            }

            socket.emit('container_stats', {
                id: containerId,
                cpu,
                memory,
                netRx: formatBytes(netRx),
                netTx: formatBytes(netTx),
                memoryRaw: formatBytes(stats.memory_stats.usage),
                memoryLimit: formatBytes(stats.memory_stats.limit)
            });
        } catch (error) {
            console.error(`Error fetching stats for ${containerId}:`, error.message);
        }
    });

    // Handle restart commands
    socket.on('restart_container', async (containerId) => {
        try {
            socket.emit('alert', { type: 'info', message: `Restarting container ${containerId.substring(0,8)}...` });
            const container = docker.getContainer(containerId);
            await container.restart();
            socket.emit('alert', { type: 'success', message: `Container ${containerId.substring(0,8)} restarted successfully.` });
            sendContainersList(socket);
        } catch (error) {
            socket.emit('alert', { type: 'error', message: `Failed to restart container: ${error.message}` });
        }
    });

    // Handle log streaming
    socket.on('subscribe_logs', async (containerId) => {
        try {
            if (activeLogStreams.has(containerId)) return;

            const container = docker.getContainer(containerId);
            const logStream = await container.logs({
                follow: true,
                stdout: true,
                stderr: true,
                tail: 50
            });

            activeLogStreams.set(containerId, logStream);

            logStream.on('data', (chunk) => {
                // Docker logs format: [8 byte header] [log message]
                // We simplify by just sending the string (might contain weird characters from header)
                // A robust implementation strips the 8 byte header per frame, but for text chunks it's mostly ok
                const logStr = chunk.toString('utf8').replace(/[\x00-\x1F\x7F-\x9F]/g, " ").trim();
                if (logStr) {
                    socket.emit('container_log', {
                        id: containerId,
                        log: logStr,
                        timestamp: new Date().toISOString()
                    });
                }
            });

            logStream.on('end', () => activeLogStreams.delete(containerId));
            logStream.on('error', () => activeLogStreams.delete(containerId));

        } catch (error) {
            console.error('Error subscribing to logs:', error.message);
        }
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
        clearInterval(listInterval);
    });
});

async function sendContainersList(socket) {
    try {
        const containers = await docker.listContainers({ all: true });
        const formattedContainers = containers.map(c => ({
            id: c.Id,
            name: c.Names[0].replace('/', ''),
            state: c.State, // running, exited, etc.
            status: c.Status, // Up 2 hours, Exited (1) 2 hours ago
            image: c.Image
        }));
        socket.emit('containers_list', formattedContainers);
    } catch (error) {
        socket.emit('alert', { type: 'error', message: 'Failed to fetch containers from Docker.' });
    }
}

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    console.log(`DockPulse 2.0 Server running on port ${PORT}`);
});
